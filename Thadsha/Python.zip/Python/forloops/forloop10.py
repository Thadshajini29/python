for x in range(1,6,1):
        print('*' * x)