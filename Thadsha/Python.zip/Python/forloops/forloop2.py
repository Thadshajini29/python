for x in range (1,12):
    
    if x%2==1:
        continue
    print(x,end='');