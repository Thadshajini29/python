'''for x in range (5,10):
    print(x);
print("\n********")    
for x in range (5,10,2):
    print(x);
    
print("\n********")    
for x in range (True):
    print(x);
    
print("\n********")    
for x in ("Thadsha"):
    print(x);
    
print("\n********")'''

    
for x in range (10):
    print(x);
    if x==5:
        break
        
print("\n********")    
for x in range (10):
    
    if x==5:
        continue
    print(x);
    
print("\n********")    
for x in range (1,12):
    
    if x%2==1:
        continue
    print(x);