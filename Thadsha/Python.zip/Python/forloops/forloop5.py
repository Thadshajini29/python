for x in range(1,6):
    if x%2==0:
        print(f"{x}**")
    else:
        print(f"{x}*")
    x+=1