for x in range(5,0,-1):
    for y in range(1,6,1):
        print(x,end='')
    print()