for x in range(1,6):
    y =x**2
    print(y)
    x+=1