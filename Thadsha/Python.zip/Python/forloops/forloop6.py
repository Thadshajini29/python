for x in range(1,5,1):
    for y in range(1,6,1):
        print(y,end='')
    print()