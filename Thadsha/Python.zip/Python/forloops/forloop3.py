for x in range(1,6):
    y = x*(x + 1)//2
    print(y)