'''x=1
while x<5:
    print(x)
    x=x+1
print(f"x = {x}")'''

'''x=1
isbool=True;
while isbool:
    print(x)
    x=x+1
    if x==5:
        isbool=False
print(f"x = {x}")'''

x=1
while x<11:
    print("Thadshajini")
    x+=1
