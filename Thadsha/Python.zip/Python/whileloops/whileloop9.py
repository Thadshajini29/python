x=5
while x>=1:
    y= 1
    while y<=5:
        print(x,end = '')
        y+=1
    print()
    x-=1 