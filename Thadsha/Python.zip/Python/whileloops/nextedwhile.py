x=1
while x<=5:
    y=1
    while y<=4:
        print(y,end='')
        y+=1
    #print(f"{x}")
    print(x)
    x+=1    