x=1
while x<=9:
    if(x%2==1):
        print(x,end='')
        
    x+=1

print("\n********")
x=1
while x<=9:
    if(x%2==1):
        print(x,end='')
        
    x+=2  
