y=1
while y<=10:
    if y%2==0:
        print(y,end='')
    y+=1    