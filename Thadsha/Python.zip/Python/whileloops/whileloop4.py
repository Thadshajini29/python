x=1
while x<=5:
    y=x**2
    print(y,end ='')
    x+=1