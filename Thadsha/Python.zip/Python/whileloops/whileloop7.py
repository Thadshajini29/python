x=1
while x<=5:
    y=5
    while y>=1:
        print(y,end = '')
        y-=1
    print()
    x+=1