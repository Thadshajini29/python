x=1
while x<=5:
    if x%2==0:
        print(f"{x}**")
    else:
        print(f"{x}*")
    x+=1