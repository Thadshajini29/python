x=1
while x<=5:
    y=1
    while y<=5:
        print(x,end='')
        y+=1
    print()
    x+=1 